export interface Objeto{
    nombre : string;
    latlng : string;
    fechaDeEncuentro : string;
}